#!/bin/bash

echo "------------------------START Miner----------------------"
./algo -t cuda -a "NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88" -p pool.acemining.co:8443 -n "My rig" --threads 10 
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
